import psycopg2
from flask import Blueprint, abort, render_template, request

from .db import get_db, query

bp = Blueprint("pages", __name__)

MAX_ROWS = 1000

TABLES_SQL = """
    SELECT quote_ident(table_name) AS name
    FROM information_schema.tables
    WHERE table_schema = 'public' AND table_type = 'BASE TABLE'
    ORDER BY table_name
"""


@bp.route("/", methods=["GET", "POST"])
def index():
    site = request.headers.get("Sec-Fetch-Site", "same-origin")
    if request.method == "POST" and site not in ("same-origin", "none"):
        abort(403)
    sql = request.form.get("sql", "")
    result, tables, database = None, [], None
    try:
        conn = get_db()
        conn.autocommit = True
        database = conn.info.dbname
        if sql.strip():
            with conn.cursor() as cur:
                result = run_sql(cur, sql)
        tables = [row["name"] for row in query(TABLES_SQL)]
    except psycopg2.Error as e:
        result = {"error": str(e)}
    return render_template(
        "index.html", sql=sql, result=result, tables=tables, database=database
    )


def run_sql(cur, sql):
    try:
        cur.execute(sql)
    except psycopg2.Error as e:
        return {"error": str(e)}
    if cur.description is None:
        return {"status": cur.statusmessage, "rowcount": cur.rowcount}
    return {
        "columns": [column.name for column in cur.description],
        "rows": cur.fetchmany(MAX_ROWS),
        "total": cur.rowcount,
    }
