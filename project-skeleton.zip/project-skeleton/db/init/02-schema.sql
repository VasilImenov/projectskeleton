CREATE TABLE note (
    note_id serial PRIMARY KEY,
    title varchar(100) NOT NULL,
    created_at timestamp NOT NULL DEFAULT now()
);

INSERT INTO note (title) VALUES ('Първа бележка');
